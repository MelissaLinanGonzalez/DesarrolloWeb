class Producto{
    constructor(nombre) {
        this.nombre = nombre;
    }
}