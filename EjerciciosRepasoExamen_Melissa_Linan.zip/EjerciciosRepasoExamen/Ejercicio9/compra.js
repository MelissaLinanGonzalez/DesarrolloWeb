class Compra{
    constructor(productos, fecha, unidades) {
        this.productos = productos;
        this.fecha = fecha;
        this.unidades = unidades;
    }
}